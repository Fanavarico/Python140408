s='$$$hello######'
u=s.lstrip('$').rstrip('#')
print(u)