l=[90,'ali',8.7,'hello']
j=len(l)
for i in range(len(l)):
    if i%2==1:
        print(l[i],end='--')

