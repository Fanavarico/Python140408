s='hello'
s[1]='y'
print(s)