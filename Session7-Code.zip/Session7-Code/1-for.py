l=[90,'ali',8.7,'hello']
j=len(l)
for i in range(len(l)):
    print(l[i],end='--')
