s='python is programming language'
u=s.split(' ',7)
print(u)