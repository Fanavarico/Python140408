w=input('enter website: ')
u=w.strip('www.')
print(u)
