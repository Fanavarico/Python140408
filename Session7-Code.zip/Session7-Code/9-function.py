l=[90,'ali',8.7,'hello','ali','Ali']
#l.append([12,20])
#l.extend(['12',30])
#print(l)
#t=l.copy()
#t=l.count('ali')
#t=l.index('ali')
#y=l.index('ali',t+1)
# print(t)
# print(y)
# l[1]='ava'
# print(l)
l.insert(1,999)
print(l)
