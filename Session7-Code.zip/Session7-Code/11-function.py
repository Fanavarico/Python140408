l=[]
while True:
    a=input('enter value: ')
    if a.lower()=='exit':
        break
    l.append(a)

    
print(l)