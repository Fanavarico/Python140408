l=[90,'ali',8.7,'hello']
print(l*5)
