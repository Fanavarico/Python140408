l=[90,'ali',8.7,'hello']
for i in l[1::2]:
    print(i)

