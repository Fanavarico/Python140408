s='#hel#lo###'
#u=s.replace('l','iiii',1)
#u=s.find('hello')
#u=s.index('z')
#u=s.count('l',0,4)
#u=s.strip('#')
#u=s.replace('#','')

print(u)
