l=[90,'ali',8.7,'hello']
#l.clear()
#print(l)

del l[2]
print(l)
