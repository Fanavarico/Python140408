l=[90,'ali',8.7,'hello','ali','Ali']
# t=l.pop(2)
# print(l)
# print(t)
# l.remove(l[2])
# print(l)
# l.reverse()
# print(l)
# del l[0:3]
# print(l)