s='ali'
#del s
print(s)
