l=[90,'ali',8.7,'hello']
l[1]='ava'
print(l)
print(len(l))

