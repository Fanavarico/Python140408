l=['python', 'is', 'programming', 'language']
u=''.join(l)
print(u)