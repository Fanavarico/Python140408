l1=[1,2]
l=[90,'ali',8.7,'hello']
print(l1+l)