
#print(f'in this year {y} , {e} happened {8+y}')
#print('in this year {}  , {} happened for {}'.format(y,e,n))
#print('in this year {y}  , {e} happened for {n}'.format(y=2028,e='corona',n='reza'))
#print('{:}'.format(310.1467864678))
#print('{:05d}'.format(42))
#print('{:b}'.format(12))
#print('{:x}'.format(10))
#print('{} {} {}'.format('hello','ali','reza'))
