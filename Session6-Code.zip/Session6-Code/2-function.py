s='h3b5j7k33'
d=''
ch=''
for i in s:
    if i.isdigit():
        d=d+i
    elif i.isalpha():
        ch=ch+i
        
print('numbers: ',d)
print('chars : ',ch)
        