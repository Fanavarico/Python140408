s='56'
#d=s.islower()
#d=s.isupper()
d=s.isdigit()
print(d)