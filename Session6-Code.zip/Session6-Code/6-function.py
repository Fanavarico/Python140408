s='gkjgkj'
f=s.isalpha()
print(f)

