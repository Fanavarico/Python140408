s=input('enter value : ')
c=0
for i in s:
    if i.isdigit():
        print(i)
        c+=1
print('number of digits is : ',c)