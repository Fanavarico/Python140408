s='asv5g78j$'
d=s.isalnum()
print(d)