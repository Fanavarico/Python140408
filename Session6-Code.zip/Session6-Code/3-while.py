total=0
running=True
while running:
    x=int(input('enter number : '))
    total+=x
    if total==100:
        print('the result is ',total)
        running=False
    elif total>100:
        total=total-x
        print('the result is ',total)
        running=False