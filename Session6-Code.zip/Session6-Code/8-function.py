s='abc5r&%g$7'
ns=''
for i in s:
    if not(i.isalnum()):
        #print(i)
        ns=ns+i
print(ns)