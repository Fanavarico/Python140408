total=0
while True:
    x=int(input('enter number : '))
    total+=x
    if total==100:
        print('the result is ',total)
        break
    elif total>100:
        total=total-x
        print('the result is ',total)
        break
    