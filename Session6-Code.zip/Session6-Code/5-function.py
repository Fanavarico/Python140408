s=input('enter value: ')

for i in range(0,len(s)):
    if s[i].isdigit():
        print(i,'-',s[i])
