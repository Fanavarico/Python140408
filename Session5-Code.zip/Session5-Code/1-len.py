s=[12,3,6,'ali',3,90.8]
print(type(s))
print(len(s))