i=0
while i<=10:  
    
    if i==5:
        continue
        
    
    i+=1
    print(i)
    