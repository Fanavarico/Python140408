total=100
s=0
while s<total:
    x=int(input('enter number : '))
    if s<100:
        s=s+x

if s>100:
    s=s-x
print('result: ',s)
