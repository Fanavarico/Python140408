x=20
y=40
a,b=x,y
print('a',a)
print('b',b)
