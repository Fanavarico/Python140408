l=[12,5,7,'ali']
for item in l:
    print(item)