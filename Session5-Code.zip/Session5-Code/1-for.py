#s='hello'
#d=''
s=input('enter value : ')
j=len(s)-1
print(j)
for i in range(j,-1,-1):
    #d=d+s[i]
    print(s[i],end='')