s=input('enter value: ')
ch=input('enter char: ')
c=0
for j in s:
    if j==ch:
        c=c+1
print(c)