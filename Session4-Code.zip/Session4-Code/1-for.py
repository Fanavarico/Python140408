'''for i in range(1,11):
    print(i)
for i in range(1,10,2):
    print(i)
for i in range(1,11):
    print(i,'-hello')

for i in range(1,10):
    print(i)'''

for i in range(100,0,-1):
    print(i)