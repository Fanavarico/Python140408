s='reza'
for i in s:
    print(i)