s=input('enter value :')
c=0
for i in s:
    c=c+1
print(c)