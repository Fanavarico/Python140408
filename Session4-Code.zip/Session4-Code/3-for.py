l=[12,4,6,'ava',['python','hello']]
c=0
for i in l:
    #c=c+1
    c+=1
    print(c,'-',i)
    
