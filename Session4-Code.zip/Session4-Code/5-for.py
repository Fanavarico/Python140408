l=[12,10,5,16,1,20]
c=0
for i in l:
    if i >10:
        c+=i
        
print(c)