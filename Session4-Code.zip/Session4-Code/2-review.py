w=float(input('وزن خود را وارد نمایید :kg: '))
h=float(input('قد خود را وارد نمایید : m: '))
bmi=w//(h**2)
#print(bmi)
if bmi<=15:
    d='سوء تغذیه'
elif bmi>15 and bmi<=16.5:
    d='خیلی لاغر'
elif 16.5<bmi<=18:
    d='لاغر'


print('با قد',h,'و وزن ',\
      w,'مقدار bmi شما',bmi,d)