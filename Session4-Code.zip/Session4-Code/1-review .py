w=float(input('وزن خود را وارد نمایید :kg: '))
h=float(input('قد خود را وارد نمایید : m: '))
bmi=w//(h**2)
#print(bmi)
if bmi<=15:
    print('با قد'+str(h)+'و وزن '+\
          str(w)+'مقدار bmi شما'+str(bmi)+'شما سوء تغذیه دارید')
elif bmi>15 and bmi<=16.5:
    print('با قد',h,'و وزن ',\
          w,'مقدار bmi شما',bmi,'شما خیلی لاغر دارید')