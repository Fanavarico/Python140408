import tkinter as tk
root = tk.Tk()
root.title("calculator")
display = tk.Label(root,text='0',width=40, height=5)
display.grid(row=0, column=0, columnspan=4)
#root.geometry('300x400')
root.resizable(False,False)
current = ""
first_number = None
operator = None


def add_0():add_digit("0")
def add_1():add_digit("1")
def add_2():add_digit("2")
def add_3():add_digit("3")
def add_4():add_digit("4")
def add_5():add_digit("5")
def add_6():add_digit("6")
def add_7():add_digit("7")
def add_8():add_digit("8")
def add_9():add_digit("9")
def add_dot():add_digit(".")


def add_digit(d):
    global current
    if d == "." and "." in current:
        return
    current =current+ d
    display.config(text=current)
    
def add_plus():set_op("+")
def add_minus():set_op("-")
def add_mul():set_op("*")
def add_div():set_op("/")

def set_op(op):
    global first_number, operator, current
    if current != "":
        first_number = float(current)
        operator = op
        current = ""
        display.config(text="0")
        
def calculator():
    global current, first_number, operator
    if current == "" or operator is None or first_number is None:
        return None
    second = float(current)
    if operator == "+":
        return first_number + second
    elif operator == "-":
        return first_number - second
    elif operator == "*":
        return first_number * second
    elif operator == "/":
        if second == 0:
            display.config(text="not true")
            current = ""
            first_number = None
            operator = None
            return None
        return first_number / second


def add_calculator():
    global current, first_number, operator
    result = calculator()
    if result is None:
        return
    current = str(result)
    display.config(text=current)
    first_number = None
    operator = None


def clear():
    global current, first_number, operator
    current = ""
    first_number = None
    operator = None
    display.config(text=0)


tk.Button(root, text="7", command=add_7).grid(row=1, column=0)
tk.Button(root, text="8", command=add_8).grid(row=1, column=1)
tk.Button(root, text="9",command=add_9).grid(row=1, column=2)
tk.Button(root, text="/", command=add_div).grid(row=1, column=3)
tk.Button(root, text="4", command=add_4).grid(row=2, column=0)
tk.Button(root, text="5", command=add_5).grid(row=2, column=1)
tk.Button(root, text="6", command=add_6).grid(row=2, column=2)
tk.Button(root, text="*", command=add_mul).grid(row=2, column=3)

tk.Button(root, text="1", command=add_1).grid(row=3, column=0)
tk.Button(root, text="2", command=add_2).grid(row=3, column=1)
tk.Button(root, text="3", command=add_3).grid(row=3, column=2)
tk.Button(root, text="-", command=add_minus).grid(row=3, column=3)

tk.Button(root, text="0", command=add_0).grid(row=4, column=0)
tk.Button(root, text=".", command=add_dot).grid(row=4, column=1)
tk.Button(root, text="+", command=add_plus).grid(row=4, column=2)
tk.Button(root, text="=", command=add_calculator).grid(row=4, column=3)

tk.Button(root, text="C", command=clear).grid(row=5, column=0, )


root.mainloop()