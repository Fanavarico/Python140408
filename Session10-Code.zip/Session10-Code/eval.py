result = eval("1 +7+8+9+6//8")
print(result)
