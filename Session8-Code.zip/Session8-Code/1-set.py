# s={'a','a','t','b','t'}
# print(s)
# print(type(s))
s={'a','a','t','b','t'}
print(s)
print(type(s))
print(len(s))
