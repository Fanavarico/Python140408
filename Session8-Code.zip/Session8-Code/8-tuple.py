t=4,80,'hello'
a,b,c=t
print('a:',a)
print('b:',b)
print('c:',c)