t1=1,2
t2=2,1
print(t1==t2)