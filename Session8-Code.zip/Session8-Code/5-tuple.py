t=8,90,'a'
l=list(t)
print(l)
l.append(7)
print(l)
t=tuple(l)
print(t)