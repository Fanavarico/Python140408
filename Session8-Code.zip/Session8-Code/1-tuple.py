t=2,9,'a'
#print(type(t))
#print(t.count('a'))
#i=t.index('za')
print(t[1])
#t[1]='hello'
print(t)