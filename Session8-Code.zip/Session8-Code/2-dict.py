d={'name':'ava','family':'b','class':6,8:70}
d1={'name':'ava','family':'b','class':6,8:70}

f=d.items()
print(f)
# print(type(f))
# for i in d.keys():
#     print(i)
# for i in d.values():
#     print(i)

for i,j in d.items():
    print(i,':',j)