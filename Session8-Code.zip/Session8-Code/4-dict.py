d={'name':'ava','family':'b','class':6,'name':'reza'}
print(d)
