# def hello():
#     print('hello ali')
    
# hello()

# def hello(s):
#     print('hello '+s)
    
# hello('ali')
# def hello():
#     return 'hello ali'

# d=hello()
# print(d)
def hello(s):
    return 'hello '+s

d=hello('ali')
print(d)



