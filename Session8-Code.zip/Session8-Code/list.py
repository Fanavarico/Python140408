s=['123','a',3]
a,b,c=s
print('a:',a)
print('b:',b)
print('c:',c)