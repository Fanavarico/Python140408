d={'name':'ava','family':'b','class':6}
# u=d.pop('name')
# print(u)
# print(d)
# h=d.popitem()
# print(h)
# print(d)
# d1={'school':'g','h':'c'}
# d1.update(d)
# print(d1)
d={'name':'ava','family':'b','class':6}
print(d)
print(len(d))