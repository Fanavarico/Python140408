l=['a','a','b','b','a','c']
d={}
for i in l:
    d[i]=d.get(i,0)+1
    print(d)

print(d)

