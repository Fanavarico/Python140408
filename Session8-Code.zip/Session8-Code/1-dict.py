d={'name':'ava','family':'b','class':6,8:70}
#d=dict(name='ava',family='b',class1=6)
#f=d.get('name1')
# print(d)
# print(type(d))
# f=d.get('name1','not found')
# print(f)
# f=d['name']
# print(f)
# d['name']='reza'
# print(d)
# j=d.values()
# print(j)
# print(type(j))
f=d.keys()
print(f)
print(type(f))