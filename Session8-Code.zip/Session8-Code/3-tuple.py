t1=12,4,'a'
t2='hello',
print(t1+t2)
