d={'name':'ava','family':'b','class':6,8:70}
d1={'name':'ava','family':'b','class':6,8:70}
l=[d,d1]
# print(l)
for i in l:
    for j,k in i.items():
        print(j,':',k)
    print('-------')

