u=(5,)
print(type(u))

