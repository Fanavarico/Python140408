s={'a','a','t','b','t'}
s1={'t','b','t','a','a','t'}
print(s==s1)
