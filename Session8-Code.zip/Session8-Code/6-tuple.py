t=8,90,'a'
l=list(t)
print(l)
l.remove(90)
print(l)
t=tuple(l)
print(t)