d={'a':3,'b':2,'c':1}
print(d['b'])
d['z']=70
print(d)