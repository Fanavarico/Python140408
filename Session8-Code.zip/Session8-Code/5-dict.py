l=['a','a','b','b','a','c']
d={}
for i in l:
    if i not in d:
        d[i]=1
    elif i in d:
        d[i]=d[i]+1
print(d)