g='ali'+' '+'reza'
j='ali '+'reza'
l='ali'+' reza'
#print(g)
#print(j)
print(l)
print(type(g))
