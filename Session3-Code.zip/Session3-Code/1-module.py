'''import math
i=math.sqrt(4)
print(i)
import random
#u=random.randint(1000000,9999999)
#print(u)
t=random.choice(['sang','kaghaz','ghachi'])
print(t)
'''
import os
print(os.getcwd())