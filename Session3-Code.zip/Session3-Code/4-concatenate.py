l1=[10,20,30]
s='reza'
l=l1+s
print(l)