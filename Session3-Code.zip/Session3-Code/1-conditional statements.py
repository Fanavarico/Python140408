num=int(input('enter number'))
if num%2==0:
    print('زوج')
elif num%2!=0:
    print('فرد')