import math
num=float(input('enter number: '))
if num>0:
    i=math.sqrt(num)
    print('my number was + and answer is ',i)

elif num<0:
    num=abs(num)
    i=math.sqrt(num)
    print(i)

elif num==0:
    print('hello')
    