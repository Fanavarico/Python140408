r=float(input('enter reduis: '))
p=3.14
#تابع محیط
def mo(y):
    return 2*y*p

#تابع مساحت
def ma(w):
    t=w*w*p
    return t
def main():
    msg=input('enter mohit or masahat: ')
    if msg=='mohit':
        print('mohit:',mo(r))
    elif msg=='masahat':
        g=ma(r)
        print('masahat:',g)
    else:
        print('enter correct value')

main()