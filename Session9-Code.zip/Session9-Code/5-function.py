a='hello'
b='welcome'
print('{a} ali {b} to class'.format(a='t',b='y'))