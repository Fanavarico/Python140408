def f(**a):
    print(a)
    
    
f()
f(name='t')
f(a='v',l='u')
