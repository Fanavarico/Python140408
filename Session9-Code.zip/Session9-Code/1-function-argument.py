def f(a,c,f,j=10,b=100):
    print(a,b,c,f,j)
    
f(10,20,40)