def hello(s):
    return 'hello '+s

d=hello('ali')
print(d)
