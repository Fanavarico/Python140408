def hello():
    
     print('hello ali')
     


hello()