import tkinter as tk
root=tk.Tk()
root.title('ماشین حساب')
root.geometry('300x400')
def say_hi():
    a=int(input('1'))
    b=int(input('2'))
    print(a*b)
tk.Button(root,text='click me',command=say_hi).pack()

root.mainloop()