def hello():
    return 'hello ali'


f=hello()
print(type(f))
