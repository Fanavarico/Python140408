def hello(s:str,t:str)->None:
    '''تابع من ورودی دارد اما خروجی ندارد'''     
    print('hello '+s)
    print('welcome '+t)
    
     
     
i=input('enter your name:') 
y=input('enter another name:')   
e=hello(i,y)
print(type(e))