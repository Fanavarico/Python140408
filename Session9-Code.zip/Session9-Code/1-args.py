def f(*a):
    return a

p=f()
print(type(p))
print(p)
t=f(10)
print(type(t))
print(t)
y=f(40,10,80,90,'a')
print(type(y))
print(y)